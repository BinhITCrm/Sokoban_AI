+==============================  FOLDER  ==============================+
| 1. Asset : chứa những ảnh để xây dựng game                           | 
| 2. Checkpoints : chứa 30 file .txt là những checkpoints cho bài toán |
| 3. Slides for presentation : chứa slide thuyết trình                 |
| 4. Sources : Chứa 4 file .py (thầy chỉ cần chạy file main.py)        |
| 5. Statistics : chứa 1 file .pdf thống kê số liệu cho 2 giải thuật   |
| 6. Testcases : chứa 30 file .txt là những map cho bài toán           |
| 7. Video : chứa đường link youtube là video trình bày của nhóm em    |
| 8. README.txt : là file này                                          |
| 9. Among-Koban.exe : một executable file để chạy chương trình nhanh  |
|    không cần mở terminal                                             |
+======================================================================+

+=======  Lưu ý khi di chuyển hoặc thay đổi tên file và folder  ========+
| 1. Khi thay đổi folder "Assets, Checkpoints, Sources, Testcases" (di  |
|    chuyển, xóa nội dung, xóa folder, đổi tên) có thể dẫn đến việc     | 
|    chương trình chính (main.py) sẽ không chạy.                        |
| 2. Cú pháp chạy chương trình là : python main.py                      |
| 3. Hoặc thầy có thể chạy file "Among-Koban.bat" để chạy chương trình  |
+=======================================================================+

+=========================  Lưu ý khi chạy game  =========================+
| 1. Một số testcase có thể lâu. Trong khi chúng đang giải, nếu thầy muốn |
|    thoát ra để chuyển sang chạy map khác, thầy sẽ phải tắt chương trình |
|    và mở lại như hướng dẫn trên.                                        |
| 2. Ngoài ra thời gian thầy sẽ đợi tối đa cho mỗi map là 30 phút vì 30   |
|    phút là timeout nhóm em cài đặt cho game                             |
+=========================================================================+